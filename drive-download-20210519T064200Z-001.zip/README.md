# web app deployed on Heroku

The deployed web app is live at https:



The web app was built in Python using the following libraries:
* streamlit